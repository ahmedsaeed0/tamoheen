@if($formMode == 'edit')

    <div class="form-group {{ $errors->has('city_from_id') ? 'has-error' : '' }}">
        {!! Form::label('city_from_id', __('admin-trip.from'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="city_from_id" name="city_from_id" required>
            <option>{{ __('admin-trip.select_from_city') }}</option>
            @foreach($cities as $city)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $city->id }}" {{ ($trip->city_from_id == $city->id) ? 'selected' : '' }}>{{ $city->name_arabic }}</option>
                @else
                    <option value="{{ $city->id }}" {{ ($trip->city_from_id == $city->id) ? 'selected' : '' }}>{{ $city->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('city_from_id', '<p class="text-danger">:message</p>') !!}
    </div>
@else
    <div class="form-group {{ $errors->has('city_from_id') ? 'has-error' : '' }}">
        {!! Form::label('city_from_id', __('admin-trip.from'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="city_from_id" name="city_from_id" required>
            <option>{{ __('admin-trip.select_from_city') }}</option>
            @foreach($cities as $city)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $city->id }}">{{ $city->name_arabic }}</option>
                @else
                    <option value="{{ $city->id }}">{{ $city->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('city_from_id', '<p class="text-danger">:message</p>') !!}
    </div>
@endif

@if($formMode == 'edit')
    <div class="form-group {{ $errors->has('city_to_id') ? 'has-error' : '' }}">
        {!! Form::label('city_to_id', __('admin-trip.to'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="city_to_id" name="city_to_id" required>
            <option>{{ __('admin-trip.select_to_city') }}</option>
            @foreach($cities as $city)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $city->id }}" {{ ($trip->city_to_id == $city->id) ? 'selected' : '' }}>{{ $city->name_arabic }}</option>
                @else
                    <option value="{{ $city->id }}" {{ ($trip->city_to_id == $city->id) ? 'selected' : '' }}>{{ $city->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('city_to_id', '<p class="text-danger">:message</p>') !!}
    </div>
@else
    <div class="form-group {{ $errors->has('city_to_id') ? 'has-error' : '' }}">
        {!! Form::label('city_to_id', __('admin-trip.to'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="city_to_id" name="city_to_id" required>
            <option>{{  __('admin-trip.select_to_city')  }}</option>
            @foreach($cities as $city)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $city->id }}">{{ $city->name_arabic }}</option>
                @else
                    <option value="{{ $city->id }}">{{ $city->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('city_to_id', '<p class="text-danger">:message</p>') !!}
    </div>
@endif

@if($formMode == 'edit')
    <div class="form-group {{ $errors->has('car_id') ? 'has-error' : '' }}">
        {!! Form::label('car_id', __('admin-trip.car'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="car_id" name="car_id" required>
            <option>{{ __('admin-trip.select_car') }}</option>
            @foreach($cars as $car)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $car->id }}" {{ ($trip->car_id == $car->id) ? 'selected' : '' }}>{{ $car->name_arabic }}</option>
                @else
                    <option value="{{ $car->id }}" {{ ($trip->car_id == $car->id) ? 'selected' : '' }}>{{ $car->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('car_id', '<p class="text-danger">:message</p>') !!}
    </div>
@else
    <div class="form-group {{ $errors->has('car_id') ? 'has-error' : '' }}">
        {!! Form::label('car_id', __('admin-trip.car'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="car_id" name="car_id" required>
            <option>{{ __('admin-trip.select_car') }}</option>
            @foreach($cars as $car)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $car->id }}">{{ $car->name_arabic }}</option>
                @else
                    <option value="{{ $car->id }}">{{ $car->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('car_id', '<p class="text-danger">:message</p>') !!}
    </div>
@endif

@if($formMode == 'edit')
    <div class="form-group {{ $errors->has('feature_id') ? 'has-error' : '' }}">
        {!! Form::label('feature_id', __('admin-trip.feature'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="feature_id" name="feature_id">
            <option>{{ __('admin-trip.select_feature') }}</option>
            @foreach($features as $feature)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $feature->id }}" {{ ($trip->feature_id == $feature->id) ? 'selected' : '' }}>{{ $feature->name_arabic }}</option>
                @else
                    <option value="{{ $feature->id }}" {{ ($trip->feature_id == $feature->id) ? 'selected' : '' }}>{{ $feature->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('feature_id', '<p class="text-danger">:message</p>') !!}
    </div>
@else
    <div class="form-group {{ $errors->has('feature_id') ? 'has-error' : '' }}">
        {!! Form::label('feature_id', __('admin-trip.feature'), ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="feature_id" name="feature_id">
            <option>{{ __('admin-trip.select_feature') }}</option>
            @foreach($features as $feature)
                @if (app()->getLocale() == 'ar')
                    <option value="{{ $feature->id }}">{{ $feature->name_arabic }}</option>
                @else
                    <option value="{{ $feature->id }}">{{ $feature->name }}</option>
                @endif
            @endforeach
        </select>
        {!! $errors->first('feature_id', '<p class="text-danger">:message</p>') !!}
    </div>
@endif

 {{-- <div class="form-group {{ $errors->has('title') ? 'has-error' : ''}}">
    {!! Form::label('title', 'Title', ['class' => 'control-label']) !!}
    {!! Form::text('title', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('title', '<p class="text-danger">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('title_arabic') ? 'has-error' : ''}}">
    {!! Form::label('title_arabic', 'Title Arabic', ['class' => 'control-label']) !!}
    {!! Form::text('title_arabic', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('title_arabic', '<p class="text-danger">:message</p>') !!}
</div> --}}
{{--<div class="form-group {{ $errors->has('title_urdu') ? 'has-error' : ''}}">
    {!! Form::label('title_urdu', 'Title Urdu', ['class' => 'control-label']) !!}
    {!! Form::text('title_urdu', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('title_urdu', '<p class="text-danger">:message</p>') !!}
</div> --}}
<div class="form-group {{ $errors->has('description') ? 'has-error' : ''}}">
    {!! Form::label('description', __('admin-trip.description'), ['class' => 'control-label']) !!}
    {!! Form::text('description', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('description', '<p class="text-danger">:message</p>') !!}
</div>
<div class="form-group {{ $errors->has('description_arabic') ? 'has-error' : ''}}">
    {!! Form::label('description_arabic', __('admin-trip.description_arabic'), ['class' => 'control-label']) !!}
    {!! Form::text('description_arabic', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('description_arabic', '<p class="text-danger">:message</p>') !!}
</div>
{{-- <div class="form-group {{ $errors->has('description_urdu') ? 'has-error' : ''}}">
    {!! Form::label('description_urdu', 'Description Urdu', ['class' => 'control-label']) !!}
    {!! Form::text('description_urdu', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']) !!}
    {!! $errors->first('description_urdu', '<p class="text-danger">:message</p>') !!}
</div> --}}

<div class="form-group {{ $errors->has('start_point') ? 'has-error' : ''}}">
    {!! Form::label('start_point', __('admin-trip.start_point'), ['class' => 'control-label']) !!}
    {!! Form::text('start_point', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'id' => 'searchStartPoint'] : ['class' => 'form-control', 'id' => 'searchStartPoint']) !!}
    {!! $errors->first('start_point', '<p class="text-danger">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('end_point') ? 'has-error' : ''}}">
    {!! Form::label('end_point', __('admin-trip.end_point'), ['class' => 'control-label']) !!}
    {!! Form::text('end_point', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'id' => 'searchEndPoint'] : ['class' => 'form-control', 'id' => 'searchEndPoint']) !!}
    {!! $errors->first('end_point', '<p class="text-danger">:message</p>') !!}
</div>


<div class="form-group datepicker-form-group {{ $errors->has('date') ? 'has-error' : ''}}">
    {!! Form::label('date', __('admin-trip.pickup_time'), ['class' => 'control-label']) !!}
    <!--{!! Form::text('date', null, ('' == 'required') ? ['class' => 'form-control datetimepicker', 'required' => 'required'] : ['class' => 'form-control datetimepicker']) !!}-->
    {!! Form::text('date', null, ('' == 'required') ? ['class' => 'form-control hijri-date-input datepickerinput', 'required' => 'required', 'id' => 'hijri-date-input-pickup'] : ['class' => 'form-control hijri-date-input pickdatepickerinput', 'id' => 'hijri-date-input-pickup']) !!}
    {!! $errors->first('date', '<p class="text-danger">:message</p>') !!}
</div>

<div class="form-group datepicker-form-group {{ $errors->has('drop_off_time') ? 'has-error' : ''}}">
    {!! Form::label('drop_off_time', __('admin-trip.drop_off_time'), ['class' => 'control-label']) !!}
    <!--{!! Form::text('drop_off_time', null, ('' == 'required') ? ['class' => 'form-control datetimepicker', 'required' => 'required'] : ['class' => 'form-control datetimepicker']) !!}-->
    
    {!! Form::text('drop_off_time', null, ('' == 'required') ? ['class' => 'form-control hijri-date-input datepickerinput', 'required' => 'required', 'id' => 'hijri-date-input'] : ['class' => 'form-control hijri-date-input datepickerinput', 'id' => 'hijri-date-input']) !!}
    {!! $errors->first('drop_off_time', '<p class="text-danger">:message</p>') !!}
</div>





{{-- <div class="form-group {{ $errors->has('type') ? 'has-error' : ''}}">
    {!! Form::label('type', 'Type', ['class' => 'control-label']) !!}
    {!! Form::select('type',(['' => 'Select Type', '1' => 'Ride', '2' => 'Shipment']), '1', ('' == 'required') ? ['class' => 'form-control js-example-basic-multiple', 'required' => 'required'] : ['class' => 'form-control js-example-basic-multiple']) !!}
    {!! $errors->first('type', '<p class="text-danger">:message</p>') !!}
</div> --}}

<!-- Material unchecked -->

<div class="form-group {{ $errors->has('type') ? 'has-error' : ''}}">
    {!! Form::label('type', __('admin-trip.type'), ['class' => 'control-label']) !!}
    <br/>
    @if($formMode == 'edit')
    <div class="custom-control custom-checkbox custom-control-inline">
      <input type="checkbox" name="type" class="custom-control-input" id="ride" value="1" {{ ($trip->type == 1) ? 'checked' : '' }}>
      <label class="custom-control-label" for="ride">{{ __('admin-trip.ride') }}</label>
    </div>

    {{-- <!-- Default inline 2-->
    <div class="custom-control custom-checkbox custom-control-inline">
      <input type="checkbox" name="type" class="custom-control-input" id="shipment" value="2" {{ ($trip->type == 2) ? 'checked' : '' }}>
      <label class="custom-control-label" for="shipment">Shipment</label>
    </div> --}}
    @else
        <div class="custom-control custom-checkbox custom-control-inline">
          <input type="checkbox" name="type" class="custom-control-input" id="ride" value="1" checked>
          <label class="custom-control-label" for="ride">{{ __('admin-trip.ride') }}</label>
        </div>

        {{-- <!-- Default inline 2-->
        <div class="custom-control custom-checkbox custom-control-inline">
          <input type="checkbox" name="type" class="custom-control-input" id="shipment" value="2">
          <label class="custom-control-label" for="shipment">Shipment</label>
        </div> --}}
    @endif
</div>


<div class="form-group {{ $errors->has('product_type_id') ? 'has-error' : '' }}" id="product_type">
    @if($formMode == 'edit')
        {!! Form::label('product_type_id', 'Product Type', ['class' => 'control-label']) !!}
        <select class="form-control js-example-basic-multiple" id="product_type_id" name="product_type_id[]" multiple="multiple">
            <option>Select Product Type</option>
            @foreach($producttypes as $key => $value)
                <option value="{{ $value }}" {{ ($trip->tripProductTypes->contains($key)) ? 'selected' : '' }}>{{ $value }}</option>
            @endforeach
        </select>

    @else

        {!! Form::label('product_type_id', 'Product Type', ['class' => 'control-label']) !!}
        <br/>
        <select class="form-control js-example-basic-multiple" id="product_type_id" name="product_type_id[]" multiple="multiple">
            <option disabled="disabled">Select Product Type</option>
            @foreach($producttypes as $key => $value)
                <option value="{{ $key }}">{{ $value }}</option>
            @endforeach
        </select>
    @endif
</div>

<div class="form-group {{ $errors->has('number_of_person') ? 'has-error' : ''}}" id="number_of_person">
    {!! Form::label('number_of_person', __('admin-trip.number_of_person'), ['class' => 'control-label']) !!}
    {!! Form::number('number_of_person', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'id' => 'input_number_of_person'] : ['class' => 'form-control', 'id' => 'input_number_of_person']) !!}
    {!! $errors->first('number_of_person', '<p class="text-danger">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('price_per_person') ? 'has-error' : ''}}" id="price_per_person">
    {!! Form::label('price_per_person', __('admin-trip.price_per_person'), ['class' => 'control-label']) !!}
    {!! Form::text('price_per_person', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required','id' => 'input_price_per_person'] : ['class' => 'form-control','id' => 'input_price_per_person']) !!}
    {!! $errors->first('price_per_person', '<p class="text-danger">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('number_of_bag') ? 'has-error' : ''}}" id="number_of_bag">
    {!! Form::label('number_of_bag', 'Number Of Bag', ['class' => 'control-label']) !!}
    {!! Form::number('number_of_bag', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'id' => 'input_number_of_bag'] : ['class' => 'form-control', 'id' => 'input_number_of_bag']) !!}
    {!! $errors->first('number_of_bag', '<p class="text-danger">:message</p>') !!}
</div>

<div class="form-group {{ $errors->has('price_per_bag') ? 'has-error' : ''}}" id="price_per_bag">
    {!! Form::label('price_per_bag', 'Price Per Bag', ['class' => 'control-label']) !!}
    {!! Form::text('price_per_bag', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'id' => 'input_price_per_bag'] : ['class' => 'form-control', 'id' => 'input_price_per_bag']) !!}
    {!! $errors->first('price_per_bag', '<p class="text-danger">:message</p>') !!}
</div>

<input type="hidden" name="capacity_of_person" id="capacity_person" />
<input type="hidden" name="capacity_of_bag" id="capacity_bag" />


<div class="form-group">
    {!! Form::submit($formMode === 'edit' ? 'تعديل رحلة' : 'إضافة رحلة', ['class' => 'btn btn-primary']) !!}
</div>

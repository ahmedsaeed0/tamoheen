<?php

return [
    //Index Page
    'withdraw_requests' => 'طلبات السحب',
    'partner' => 'شريك',
    'payment_method' => 'طريقة الدفع او السداد',
    'amount' => 'مقدار',
    'status' => 'حالة',
    'accept' => 'قبول',
    'pending' => 'قيد الانتظار',
    'actions' => 'أجراءات',
    'accept_withdraw' => 'قبول طلب السحب',
];

<?php

return [
    //Index
    'tripbookings' => 'حجوزات الرحلات',
    'total_price' => 'السعر الكلي',
    'name' => 'اسم',
    'price' => 'السعر',
    'method' => 'طريقة',
    'status' => 'حالة',
    'complete' => 'إكمال',
    'pending' => 'قيد الانتظار'

];

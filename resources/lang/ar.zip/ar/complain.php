<?php

return [
	'complain' => 'تقديم شكوى',
	'let_us_know' => 'معلومات الايميل',
	'title' => 'الاسم',
	'description' => 'تفاصيل الشكوى ',
	'submit' => 'تقديم',
];
<?php

return [
	'delivery_details' => 'اضافه معلومات التوصيل للارجاع',
];
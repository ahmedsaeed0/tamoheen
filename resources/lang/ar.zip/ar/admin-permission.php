<?php

return [
    'permission_list' => 'قائمة الأذونات',
    'update' => 'تحديث',
];

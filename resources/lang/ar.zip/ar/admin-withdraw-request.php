<?php

return [
    //Index Page
    'create_new_withdraw_request' => 'إنشاء طلب سحب جديد',
    'back' => 'عودة',
    'payment_method' => 'طريقة الدفع او السداد',
    'amount' => 'مقدار',
    'update' => 'تحديث',
    'create' => 'انشاء طلب',
    'select_payment_method' => '---اختار طريقة الدفع---'

];

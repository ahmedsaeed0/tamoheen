<?php

return [
	'address' => 'العنوان',
	'add_address' => 'اضافه عنوان',
];
<?php

return [
    //Create page
    'create_new_trip' => 'إنشاء رحلة جديدة',
    'back' => 'عودة',
    //Edit Page
    'edit_trip' => 'تحرير الرحلة',
    'back' => 'عودة',

    //Form Page
    'from' => 'مدينة المغادرة',
    'select_from_city' => 'حدد من المدينة',
    'to' => 'مدينة الوصول',

    'select_to_city' => 'اختر المدينة',
    'car' => 'المركبات',
    'select_car' => 'حدد المركبة',
    'feature' => 'ميزة',
    'select_feature' => 'حدد الميزة',
    'description' => 'الوصف',
    'start_point' => '',
    'end_point' => 'نقطة البداية',
    'pickup_time' => 'حدد موعد المغادرة',
    'drop_off_time' => 'وقت الوصول المتوقع',
    //Index Page

    'trip' => 'الرحلات',
    'add_new_trips' => 'إضافة رحلات جديدة',
    'title' => 'عنوان',
    'date' => 'تاريخ',
    'start_point' => 'نقطة الانطلاق',
    'end_point' => 'نقطة الوصول',
    'actions' => 'أجراءات',
    'trip_copy' => 'نسخة الرحلة',
    'save' => 'حفظ',
    'close' => 'قريب',
    'trip_discount' => 'خصم الرحلة',



    //Show Page
    'back' => 'العودة',
    'id' => 'ID',
    'user' => 'مستخدم',
    'title' => 'عنوان',
    'title_arabic' => 'العنوان عربي',
    'from' => 'مدينة المغادرة',
    'to' => 'مدينة الوصول',
    'car' => 'المركبات',
    'feature' => 'ميزة',
    'description' => 'الوصف',
    'description_arabic' => 'الوصف بالعربي',
    'number_of_person' => 'عدد الأشخاص',
    'number_of_bag' => 'عدد الحقائب',
    'price_per_person' => 'السعر للفرد',
    'price_per_bag' => 'السعر لكل حقيبة',
    'discount' => 'خصم',
    'start_point' => 'نقطة الانطلاق',
    'end_point' => 'نقطة الوصول',
    'date' => 'تاريخ',
    'type' => 'نوع الخدمة',
    'ride' => 'رحلة سفر',
    'shipment' => 'شحنة',
    'product_type' => 'نوع المنتج',
    'create' => 'انشاء رحلة',
];

<?php

return [
    //Create page

    //Edit Page

    //Form Page

    //Index Page
    'complains' => 'قائمة الشكاوى',
    'trip' => 'رحلة',
    'complain_from' => 'يشكو من',
    'complain_to' => 'يشكو ل',
    'complain_title' => 'عنوان الشكوى',
    'actions' => 'أجراءات',
    'delete_complain' => 'حذف الشكوى'

    //Show Page
];

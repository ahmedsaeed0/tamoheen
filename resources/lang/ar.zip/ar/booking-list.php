<?php

return [
	'booking_list' => 'قائمه الحجز',
	'trip' => 'الرحله',
	'number_of_person' => 'عدد المسافرين',
	'number_of_bag' => 'عدد الحقائب',
	'price' => 'السعر',
	'paymentstatus' => 'حاله الدفع',
	'bookingstatus' => 'حاله الحجز',
	'actions' => 'معلق',
	'complete' => 'مكتمل',
	'incomplete' => 'غير مكتمل',
	'success' => 'تم بنجاح',
	'checked_in' => 'تسجيل دخول',
	'checked_out' => 'تسجيل خروج',
	'completed' => 'مكتمل',
	'review' => 'تقييم',
	'complain' => 'شكوى',
];
<?php

return [
	'delivery_details' => 'معلومات التوصيل اوالارجاع',
];
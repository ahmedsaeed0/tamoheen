<?php

return [
	'complain' => 'Complain',
	'let_us_know' => 'Let us know who you are',
	'title' => 'Title',
	'description' => 'Description',
	'submit' => 'Submit',
];
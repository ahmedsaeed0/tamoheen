<?php

return [
	'address' => 'Address',
	'add_address' => 'Add Address',
];
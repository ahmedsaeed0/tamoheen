<?php

return [
	'delivery_details' => 'Delivery Details',
	'added' => 'Trip added',
	'updated' => 'Trip updated',
	'deleted' => 'Trip deleted',
	'canceled' => 'Trip canceled',
	'CanComplete' => 'Can not Complete',
    'Completed' => 'Trip Completed!',
    'Copied' => 'Trip Copied!',
    'Discount' => 'Discount added!',
    'cancel_alert' => 'Trip Cancel Successfull',
    'address_delete' => 'Address deleted!',
    'complain_submit' => 'Complain submitted!',
    'review_submit' => 'Review submitted!',

];
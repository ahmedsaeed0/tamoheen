<?php

return [
    //Index
    'tripbookings' => 'TripBookings',
    'total_price' => 'Total Price',
    'name' => 'Name',
    'price' => 'Price',
    'method' => 'Method',
    'status' => 'Status',
    'complete' => 'Complete',
    'pending' => 'Pending'

];

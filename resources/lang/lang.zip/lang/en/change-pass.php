<?php

return [
	'change_pass' => 'Change Password',
	'let_us_know' => 'Let us know who you are',
	'old_pass' => 'Old Password',
	'new_pass' => 'New Password',
	'con_pass' => 'Confirm Password',
	'update' => 'Update',
];
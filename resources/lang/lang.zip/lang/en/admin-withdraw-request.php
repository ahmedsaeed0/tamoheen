<?php

return [
    //Index Page
    'create_new_withdraw_request' => 'Create New Withdraw Request',
    'back' => 'Back',
    'payment_method' => 'Payment Method',
    'amount' => 'Amount',
    'update' => 'Update',
    'create' => 'Create',
    'select_payment_method'=>'---Select Payment Method---'
];

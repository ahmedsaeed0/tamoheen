<?php

return [
    //Index Page
    'withdraw_requests' => 'Withdraw Requests',
    'partner' => 'Partner',
    'payment_method' => 'Payment Method',
    'amount' => 'Amount',
    'status' => 'Status',
    'accept' => 'Accept',
    'pending' => 'Pending',
    'actions' => 'Actions',
    'accept_withdraw' => 'Accept WithdrawRequest',
];

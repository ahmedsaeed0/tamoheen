<?php

return [
    //Create Page
    'create_new_category' => 'Create New Category',
    'back' => 'Back',

    //Edit Page
    'edit_category' => 'Edit Category',

    //Form Page
    'categories' => 'Categories',
    'add_new_category' => 'Add New Category',
    'name' => 'Name',
    'name_arabic' => 'Name Arabic',
    'update' => 'Update',
    'create' => 'Create',


    //Index Page
    'actions' => 'Actions',
    'view_category' => 'View Category',
    'edit_category' => 'Edit Category',
    'delete_category' => 'Delete Category',

    //Show Page
    'show_category' => 'Show Category',
    'id' => 'ID',
];

<?php

return [
	'delivery_details' => 'Delivery Details',
	
	  // flash message 
    'added' => 'Partner Payment Method added!',
	'updated' => 'Partner Payment Method updated!',
	'deleted' => 'Partner Payment Method deleted!',
];
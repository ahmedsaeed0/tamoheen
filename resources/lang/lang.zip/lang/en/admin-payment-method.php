<?php

return [
    //Create Page
    'create_new_partner_payment_method' => 'Create New Partner Payment Method',
    'back' => 'Back',

    //Edit Page
    'edit_partner_payment_method' => 'Edit  Partner Payment Method',
    'back' => 'Back',

    //Form Page

    'name_arabic' => 'Name Arabic',
    'details' => 'Details',
    'update' => 'Update',
    'create' => 'Create',




    //Index Page
    'partner_payment_method' => 'Partner Payment Methods',
    'add_new_partner_payment_method' => 'A New Partner Payment Method',
    'user' => 'User',
    'name' => 'Name',
    'details' => 'Details',
    'actions' => 'Actions',
    'view_partner_payment_method' => 'View PartnerPaymentMethod',

    //Show Page
    'partner_payment_method' => 'Partner Payment Methods',
    'show_category' => 'Show Category',
    'user' => 'User',
    'name' => 'Name',
    'details' => 'Details',

];

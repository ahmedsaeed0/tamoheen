<?php

return [
    //Create Page
    'create_new_product_type' => 'Create New Product Type',
    'back' => 'Back',

    //Edit Page
    'edit_product_type' => 'Edit Product Type',

    //Form page
    'name' => 'Name',
    'name_arabic' => 'Name Arabic',
    'update' => 'Update',
    'create' => 'Create',

    //Index page
    'product_types' => 'Product Types',
    'add_new_product_type' => 'Add New Product Type',
    'actions' => 'Actions',
    'view_product_type' => 'View ProductType',
    'delete_product_type' => 'Delete ProductType',

    //Show page
    'show_product_type' => 'Show Of Product Type',
    'id' => 'ID',
];

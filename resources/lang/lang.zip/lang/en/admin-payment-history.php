<?php

return [
    //Index Page
    'partner_payment_history' => 'Partner Payment History',
    'back' => 'Back',
    'partner' => 'Partner',
    'price' => 'Price',
    'partner_price' => 'Partner Price',
    'type' => 'Type',
    'actions' => 'Actions',
    'view_partner_payment_history' => 'View Partner Payment Hostory',
    'partner_id' => 'Partner ID',
    'partner_name' => 'Partner Name',

    //Show Page
    'partner_payment_history' => 'Partner Payment History',
    'id' => 'ID',
    'booking_user' => 'Booking User',
    'trip_name' => 'Trip Name',
    'trip_no' => 'Trip No',
    'trip_date_time' => 'Date & Time',
    'trip_driver' => 'Driver',
    ''
];

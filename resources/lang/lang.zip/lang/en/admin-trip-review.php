
<?php

return [
    //Create page

    //Edit Page

    //Form Page

    //Index Page
    'reviews' => 'Reviews',
    'trip' => 'Trip',
    'rating_from' => 'Rating From',
    'rating_to' => 'Rating To',
    'rating' => 'Rating',
    'review' => 'Review',
    'actions' => 'Actions',
    'delete_city'=>'Delete City'

    //Show Page
];



<?php

return [
    //Create Page
    'create_new_service_charge' => 'Create New Service Charge',
    'back' => 'Back',

    //Edit Page
    'edit_service_charge' => 'Edit Service Charge',

    //Form Page
    'type' => 'Type',
    'trip' => 'Trip',
    'shipment' => 'Shipment',
    'charge' => 'Charge',
    'update' => 'Update',
    'create' => 'Create',

    //Index Page
    'service_charges' => 'Service Charges',
    'add_new_service_charges' => 'Add New Service Charges',
    'actions' => 'Actions',
    'view_service_charge' => 'View ServiceCharge',
    'edit_service_charge' => 'Edit ServiceCharge',
    'delete_service_charge' => 'Delete ServiceCharge',

    //Show Page
    'show_service_charge' => 'Show Service Charge',
    'id' => 'ID'

];

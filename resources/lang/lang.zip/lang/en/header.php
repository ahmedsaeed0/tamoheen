<?php

return [
    'dashboard'=>'Dashboard',
    // 'tel_num' => '0508724497',
    'tel_num' => '966508724497',
    'info_email' => 'info@tamoheen.com',
    'sign_in' => 'Sign in',
    'registration' => 'Regsitration',
    'order_list'=> 'Order List',
    'booking_list'=> 'Trip Booking List',
    'ship_booking_list'=> 'Ship Booking List',
    'change_password'=> 'Change Password',
    'payment_method'=> 'Payment Method',
    'logout'=> 'Logout',
    'mytravel' => 'MyTravel',
    'home' => 'Home',
    'shop' => 'Shop',
    'rideshare' => 'RideShare',
    'coming_soon' => 'Coming Soon',
    'go_to_home' => 'Go To Home',
    'sorry_to_late' => 'Sorry To Late',
    'terms_and_condition'=>'Terms & Conditions',
    
    'update_profile'=>'Update Profile'
];
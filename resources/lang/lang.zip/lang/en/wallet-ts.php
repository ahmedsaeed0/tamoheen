<?php

return [
	'delivery_details' => 'Delivery Details',
	'title'			   => 'Total Amount',
	'wallet_manage'	   => 'Wallet Management',
	'returning'	   	   => 'Remaining Balance',
];
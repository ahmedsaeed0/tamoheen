<?php

return [
    'permission_list' => 'Permission List',
    'update' => 'Update',
];

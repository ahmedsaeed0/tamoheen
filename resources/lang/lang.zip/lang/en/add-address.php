<?php

return [
	'delivery_details' => 'Delivery Details',
	'flat_no' => 'Flat No',
	'location' => 'Location',
	'select_country' => 'Select Country',
	'pin_code' => 'Pin Code',
	'phone' => 'Phone',
	'add_detail' => 'Add Detail',
];

<?php

return [
    //Create page

    //Edit Page

    //Form Page

    //Index Page
    'complains' => 'Complains',
    'trip' => 'Trip',
    'complain_from' => 'Complain From',
    'complain_to' => 'Complain To',
    'complain_title' => 'Complain Title',
    'actions' => 'Actions',
    'delete_complain' => 'Delete Complain',
    'description' => 'Description',
    'date'=>'Date'

    //Show Page
];



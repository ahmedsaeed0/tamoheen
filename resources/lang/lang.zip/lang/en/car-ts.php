<?php

return [
	'delivery_details' => 'Delivery Details',
	  // flash message 
    'added' => 'Car created',
	'updated' => 'Car updated',
	'warning' => 'You are not valid here',
	'deleted' => 'Car deleted',
];
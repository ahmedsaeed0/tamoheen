<?php

return [
    //Create Page
    'create_new_promo_code' => 'Create New Promo Code',
    'back' => 'Back',

    //Edit Page
    'edit_promo_code' => 'Edit Promo Code',

    //Form Page
    'code' => 'Code',
    'type' => 'Type',
    'percent' => 'Percent',
    'amount' => 'Amount',
    'update' => 'Update',
    'create' => 'Create',

    //Index page
    'promo_codes' => 'Promo Codes',
    'add_promo_code' => 'Add Promo Code',
    'actions' => 'Actions',
    'edit_promo_code' => 'Edit Promo Code',
    'delete_promo_code' => 'Delete_promo_code'
];

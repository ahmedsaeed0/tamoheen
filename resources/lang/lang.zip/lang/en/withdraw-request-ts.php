<?php

return [
	'delivery_details' => 'Delivery Details',
	
	  // flash message 
    'added' => 'WithdrawRequest added!',
    'danger' => 'Insufficient Amount!',
	'updated' => 'Withdraw Request updated!',
	'accepted' => 'Withdraw Request Accepted!',
	'deleted' => 'WithdrawRequest deleted!',
];
<?php

return [
	'delivery_details' => 'Delivery Details',
	
    // 	flash message 
    'admin_add' => 'Admin created',
    'pass_update' => 'Password Updated!',
    'pass_confirm' => 'New Password and Confirm password not matching!',
    'registration' => 'Registration Successful',
    'inactive' => 'User Inactive Successfully',
    'active' => 'User Active Successfully',
    'updated' => 'Profile Updated Successfully.',
    
];
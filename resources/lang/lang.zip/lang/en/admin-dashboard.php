<?php

return [
    'total_amount' => 'Total Amount',
    'total_trip' => 'Total Trip',
    'total_user' => 'Total User',
    'total_sale' => 'Total Sale',
    'total_partner' => 'Total Partner',
    'trip_booking' => 'Trip Booking',
    'ship_booking' => 'Ship Booking',
    'product_sales' => 'Product Sales',
    'trip_sales' => 'Trip Sales',
    'shipment_sales' => 'Shipment Sales',
];

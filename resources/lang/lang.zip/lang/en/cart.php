<?php

return [
	'cart' => 'Cart',
	'remove' => 'Remove',
	'image' => 'Image',
	'quantity' => 'Quantity',
	'name' => 'Name',
	'price' => 'Price',
	'continue_shop' => 'Continue Shopping',
	'add_delivery_details' => 'Add Delivery Details',
];
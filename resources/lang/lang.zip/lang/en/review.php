<?php

return [
	'review' => 'Review',
	'let_us_know' => 'Let us know who you are',
	'rating' => 'Rating',
	'select_rating' => 'Select Rating',
	'submit' => 'Submit',
];
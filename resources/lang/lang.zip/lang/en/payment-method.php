<?php

return [
	'payment_method' => 'Payment Method',
	'new_payment_method' => 'Create New Payment Method',
	'name' => 'Name',
	'details' => 'Details',
	'create' => 'Create',
];
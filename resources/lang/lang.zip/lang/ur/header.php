<?php

return [
    'tel_num' => '(000) 999 - 898 -999',
    'info_email' => 'info@mytravel.com',
    'sign_in' => 'سائن ان',
    'registration' => 'اندراج',
    'order_list'=> 'آرڈر لسٹ',
    'booking_list'=> 'بکنگ کی فہرست',
    'change_password'=> 'پاس ورڈ تبدیل کریں',
    'payment_method'=> 'ادائیگی کا طریقہ',
    'logout'=> 'لاگ آوٹ',
    'mytravel' => 'مائی ٹراویل',
    'home' => 'گھر',
    'shop' => 'دکان',
    'rideshare' => 'رائڈشیر',
    'coming_soon' => 'Coming Soon',
    'go_to_home' => 'Go To Home',
    'sorry_to_late' => 'Sorry To Late',
];
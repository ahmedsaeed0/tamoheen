<?php

return [
	'site_title' => 'رائڈ شیئر',
	'dashboard' => 'ڈیش بورڈ',
];
<?php

return [
	'booking_list' => 'Booking List',
	'trip' => 'Trip',
	'number_of_person' => 'Number Of Person',
	'number_of_bag' => 'Number Of Bag',
	'price' => 'Price',
	'paymentstatus' => 'PaymentStatus',
	'bookingstatus' => 'BookingStatus',
	'actions' => 'Actions',
	'complete' => 'Complete',
	'incomplete' => 'Incomplete',
	'success' => 'Success',
	'checked_in' => 'Checked In',
	'checked_out' => 'Checked Out',
	'completed' => 'Completed',
	'review' => 'Review',
	'complain' => 'Complain',
];
<?php

return [
    //Create page

    //Edit Page

    //Form Page

    //Index Page
    'complains' => 'قائمة الشكاوى',
    'trip' => 'رقم الرحلة',
    'complain_from' => 'اسم العميل',
    'complain_to' => 'يشكو ل',
    'complain_title' => 'عنوان الشكوى',
    'actions' => 'أجراءات',
    'delete_complain' => 'حذف الشكوى',
    'description' => 'وصف',
    'date'=>'تاريخ الرحلة'
    //Show Page
];

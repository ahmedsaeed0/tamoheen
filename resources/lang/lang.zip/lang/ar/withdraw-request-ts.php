<?php

return [
	'delivery_details' => 'Delivery Details',
	
	  // flash message 
    'added' => 'تمت إضافة طلب سحب',
    'danger' => 'كمية غير كافية',
	'updated' => 'تم تحديث طلب السحب',
	'accepted' => 'سحب الطلب مقبول',
	'deleted' => 'تم حذف طلب السحب',
];
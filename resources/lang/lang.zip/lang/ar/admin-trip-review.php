
<?php

return [
    //Create page

    //Edit Page

    //Form Page

    //Index Page
    'reviews' => 'المراجعات',
    'trip' => 'رحلة',
    'rating_from' => 'التقييم من',
    'rating_to' => 'يشكو ل',
    'rating' => 'تقييم',
    'review' => 'إعادة النظر',
    'actions' => 'أجراءات',
    'delete_city'=>'حذف المدينة'

    //Show Page
];



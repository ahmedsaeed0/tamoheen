<?php

return [
	'cart' => 'عربه التسوق',
	'remove' => 'للحذف',
	'image' => 'صورة',
	'quantity' => 'عدد',
	'name' => 'اسم المنتج',
	'price' => 'السعر',
	'continue_shop' => 'متابعه التسوق',
	'add_delivery_details' => 'اضافه معلومات التوصيل والاستلام',
];
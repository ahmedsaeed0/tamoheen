<?php

return [
	'delivery_details' => 'Delivery Details',
	 
    // flash message 
    'added' => 'تمت إضافة طريقة دفع الشريك',
	'updated' => 'تم تحديث طريقة دفع الشريك',
	'deleted' => 'تم حذف طريقة دفع الشريك',
];
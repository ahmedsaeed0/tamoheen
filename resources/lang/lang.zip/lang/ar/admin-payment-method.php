<?php

return [
    //Create Page
    'create_new_partner_payment_method' => 'إنشاء طريقة دفع جديدة للشريك',
    'back' => 'عودة',

    //Edit Page
    'edit_partner_payment_method' => 'تحرير طريقة الدفع الشريك',
    'back' => 'عودة',

    //Form Page

    'name_arabic' => 'الاسم عربي',
    'details' => 'تفاصيل',
    'update' => 'تحديث',
    'create' => 'إنشاء طلب',



    //Index Page
    'partner_payment_method' => 'طرق دفع الشريك',
    'add_new_partner_payment_method' => 'طريقة دفع جديدة للشريك',
    'user' => 'مستخدم',
    'name' => 'اسم',
    'details' => 'تفاصيل',
    'actions' => 'أجراءات',
    'view_partner_payment_method' => 'عرض طريقة دفع الشريك',

    //Show Page
    'partner_payment_method' => 'طرق دفع الشريك',
    'show_category' => 'عرض الفئة',
    'user' => 'مستخدم',
    'name' => 'اسم',
    'details' => 'تفاصيل',

];

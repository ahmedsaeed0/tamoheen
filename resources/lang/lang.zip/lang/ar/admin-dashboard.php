<?php

return [
    'total_amount' => 'المبلغ الإجمالي',
    'total_trip' => 'إجمالي الرحلة',
    'total_user' => 'إجمالي المستخدم',
    'total_sale' => 'إجمالي البيع',
    'total_partner' => 'مجموع الشريك',
    'trip_booking' => 'حجز الرحلة',
    'ship_booking' => 'حجز السفن',
    'product_sales' => 'مبيعات المنتجات',
    'trip_sales' => 'مبيعات الرحلات',
    'shipment_sales' => 'مبيعات الشحن',
];

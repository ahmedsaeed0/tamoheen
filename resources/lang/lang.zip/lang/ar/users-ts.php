<?php

return [
	'delivery_details' => 'Delivery Details',
	
    // 	flash message 
    'admin_add' => 'تم إنشاء المسؤول',
    'pass_update' => 'تم تحديث كلمة السر',
    'pass_confirm' => 'كلمة المرور الجديدة وتأكيد كلمة المرور غير متطابقين',
    'registration' => 'تم التسجيل بنجاح',
    'inactive' => 'المستخدم غير نشط بنجاح',
    'active' => 'تم تنشيط المستخدم بنجاح',
    'updated' => 'تم تحديث الملف الشخصي بنجاح',
    
];
<?php

return [
	'delivery_details' => 'تفاصيل التسليم',
	'added' => 'تمت إضافة الرحلة',
	'updated' => 'تم تحديث الرحلة',
	'deleted' => 'تم حذف الرحلة',
	'canceled' => 'تم إلغاء الرحلة',
	'CanComplete' => 'لا يمكن إكمال!',
    'Completed' => 'اكتملت الرحلة!',
    'Copied' => 'تم نسخ الرحلة!',
    'Discount' => 'تمت إضافة خصم الرحلة!',
    'cancel_alert' => 'تم إلغاء الرحلة بنجاح',
    'address_delete' => 'تم حذف العنوان!',
    'complain_submit' => 'تقديم الشكوى',
    'review_submit' => 'تم إرسال المراجعة',
];
<?php

return [
    //Index Page
    'partner_payment_history' => 'سجل مدفوعات الشريك',
    'back' => 'عودة',
    'partner' => 'شريك',
    'price' => 'السعر',
    'partner_price' => 'سعر الشريك',
    'type' => 'نوع',
    'actions' => 'أجراءات',
    'view_partner_payment_history' => 'عرض محفوظات مدفوعات الشريك',

    //Show Page
    'partner_payment_history' => 'سجل مدفوعات الشريك',
    'id' => 'بطاقة تعريف',
    'booking_user' => 'مستخدم الحجز',
    'trip_name' => 'اسم رحلة',
];

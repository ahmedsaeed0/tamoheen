<?php

return [
    'dashboard'=>'لوحة القيادة',
    'tel_num' => '0508724497',
    'info_email' => 'info@tamoheen.com',
    'sign_in' => 'تسجيل الدخول',
    'registration' => 'التسجيل',
    'order_list'=> 'لائحة الطلبات',
    'booking_list'=> 'قائمة الحجز',
    'change_password'=> 'تغيير كلمة المرور',
    'logout'=> 'تسجيل خروج',
    'mytravel' => 'رحلتي',
    'home' => 'الصفحة الرئيسية',
    'shop' => 'متجر التسوق',
    'rideshare' => 'مشاركة الرحلة',
    'coming_soon' => 'انتظرونا قريبا',
    'go_to_home' => 'الصفحه الرئيسيه',
    'sorry_to_late' => 'ناسف على التاخير',
    'update_profile'=>'تحديث الملف'
];

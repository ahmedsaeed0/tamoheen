<?php

return [
    //Create Page
    'create_new_promo_code' => 'إنشاء رمز ترويجي جديد',
    'back' => 'عودة',

    //Edit Page
    'edit_promo_code' => 'تحرير الرمز الترويجي',

    //Form Page
    'code' => 'رمز',
    'type' => 'نوع',
    'percent' => 'نسبه مئويه',
    'amount' => 'مقدار',
    'update' => 'تحديث',
    'create' => 'يخلق',

    //Index page
    'promo_codes' => 'رموز الترويجي',
    'add_promo_code' => 'أضف الرمز الترويجي',
    'actions' => 'أجراءات',
    'edit_promo_code' => 'تحرير الرمز الترويجي',
    'delete_promo_code' => 'حذف الرمز الترويجي'
];

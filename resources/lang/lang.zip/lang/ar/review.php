<?php

return [
	'review' => 'التقييم',
	'let_us_know' => 'بريدك الالكتروني',
	'rating' => 'التقييم',
	'select_rating' => 'اختار التقييم',
	'submit' => 'ارسال',
];
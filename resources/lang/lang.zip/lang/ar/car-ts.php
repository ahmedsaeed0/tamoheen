<?php

return [
	'delivery_details' => 'اضافه معلومات التوصيل للارجاع',

      // flash message 
    'added' => 'تم إنشاء السيارة',
	'updated' => 'السيارة محدثة',
	'warning' => 'أنت غير صالح هنا',
	'deleted' => 'تم حذف السيارة',
];
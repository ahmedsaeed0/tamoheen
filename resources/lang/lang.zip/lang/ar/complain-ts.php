<?php

return [
	'delivery_details' => 'معلومات التوصيل او الارجاع',
];
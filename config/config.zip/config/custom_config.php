<?php
ini_set('allow_url_fopen', '1');
